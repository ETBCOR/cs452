/* * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Class:       CS452 (Real-Time Operating Systems)  *
 * Instructor:  John Shovic                          *
 * Student:     Ethan Corgatelli (corg7983)          *
 * Project:     Assignment 7                         *
 * File:        main.c                               *
 *                                                   *
\* * * * * * * * * * * * * * * * * * * * * * * * * * */

//---------------- INCLUDES ----------------//
#include <math.h>
#include <FreeRTOS.h>
#include <queue.h>
#include <tusb.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/i2c.h"


//---------------- DEFINITIONS ----------------//

#define DBG false
#define TASK_STACK_SIZE 256
#define I2C_TIMEOUT 500 * 1000 // in us

// Information for the HDC1080 sensor and I2C bus mode
#define I2C_ADDRESS 0x40
#define I2C_PORT i2c1
#define TI_MFID 0x5449
#define HDC1080_DVID 0x1050
#define HDC1080_TMP_REG 0x00
#define HDC1080_HMD_REG 0x01
#define HDC1080_CNF_REG 0x02
#define HDC1080_SN1_REG 0xFB
#define HDC1080_SN2_REG 0xFC
#define HDC1080_SN3_REG 0xFD
#define I2C_MFID_REG 0xFE
#define I2C_DVID_REG 0xFF
enum HDC1080_REG {
    TMP_REG,
    HMD_REG,
    CNF_REG,
    SN1_REG,
    SN2_REG,
    SN3_REG,
    MFID_REG,
    DVID_REG
};

// LED PIN
const uint LED_PIN = PICO_DEFAULT_LED_PIN;


//---------------- PROTOTYPES / HANDLES ----------------//

// Utility function prototypes
static bool i2c_init_HDC1080();
static int  read_hdc_reg(enum HDC1080_REG);
static bool i2c_w(const uint8_t *, size_t);
static bool i2c_r(uint8_t *, size_t);
static void cls();

// Task prototypes
static void vHDC1080Tsk();
static void vBlinkerTsk();

// Task/queue handles
static TaskHandle_t  xHDC1080Tsk  = NULL;
static TaskHandle_t  xBlinkerTsk  = NULL;
static QueueHandle_t xTmpHmdQueue = NULL;


//---------------- MAIN ----------------//
int main()
{
    // Initialization
    stdio_init_all();
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    while (!tud_cdc_connected()) { sleep_ms(100); }
    cls();
    sleep_ms(10);
    printf("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n┃ Serial debugging connected! ┃\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n");
    

    // HDC1080 detection
    printf("Looking for the HDC1080 sensor...\n");
    while (!i2c_init_HDC1080()) { sleep_ms(1000); printf("Retrying...\n"); }
    printf("HDC1080 connected!\n");

    // Create the tasks
    xTaskCreate(vHDC1080Tsk, "HDC1080_Task", TASK_STACK_SIZE, NULL, 1, &xHDC1080Tsk);
    xTaskCreate(vBlinkerTsk, "Blinker_Task", TASK_STACK_SIZE, NULL, 1, &xBlinkerTsk);

    // start the task scheduler
    vTaskStartScheduler();

    while(1){}
}


//---------------- UTILITY FUNCTIONS ----------------//

// Function to initialize the I2C bus for the HDC1080 sensor.
// * Returns false if the sensor is not detected.
static bool i2c_init_HDC1080()
{
    int config, sn1, sn2, sn3, mfID, dvID;

    // Set up I2C1 (the default SDA and SCL pins) functionality
	i2c_init(I2C_PORT, 100 * 1000); 
    gpio_set_function(PICO_DEFAULT_I2C_SDA_PIN, GPIO_FUNC_I2C);
	gpio_set_function(PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C);
	gpio_pull_up(PICO_DEFAULT_I2C_SDA_PIN);
	gpio_pull_up(PICO_DEFAULT_I2C_SCL_PIN);

	// Make the I2C pins available to picotool
	bi_decl(bi_2pins_with_func(PICO_DEFAULT_I2C_SDA_PIN,PICO_DEFAULT_I2C_SCL_PIN,GPIO_FUNC_I2C));

    // Read in the registers' data
    if ((mfID = read_hdc_reg(MFID_REG)) != TI_MFID
    ||  (dvID = read_hdc_reg(DVID_REG)) != HDC1080_DVID) return false;
    config = read_hdc_reg(CNF_REG);
    sn1 = read_hdc_reg(SN1_REG);
    sn2 = read_hdc_reg(SN2_REG);
    sn3 = read_hdc_reg(SN3_REG);
    if (config == -1 || sn1 == -1 || sn2 == -1 || sn3 == -1 || mfID == -1 || dvID == -1) return false;

    // Print out the data that was just read
    // printf("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
    // printf("\n┃ The HDC1080 sensor was detected.        ┃");
    // printf("\n┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫");
    // printf("\n┃\tConfiguration:    0x%02x\t  ┃", config   );
    // printf("\n┃\tSerial ID:        %02x-%02x-%02x\t  ┃", sn1, sn2, sn3);
    // printf("\n┃\tManufacturer ID:  0x%02x\t  ┃", mfID     );
    // printf("\n┃\tDevice ID:        0x%02x\t  ┃", dvID       );
    // printf("\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n");
    printf("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n┃ The HDC1080 sensor was detected.        ┃\n┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫\n┃\tConfiguration:    0x%02x\t  ┃\n┃\tSerial ID:        %02x-%02x-%02x\t  ┃\n┃\tManufacturer ID:  0x%02x\t  ┃\n┃\tDevice ID:\t  0x%02x\t  ┃\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n", config, sn1, sn2, sn3, mfID, dvID);

    // HDC1080 found: return success
    return true;
}

// Reads from a register on the HDC1080 using an i2c_w and an i2c_r
int read_hdc_reg(enum HDC1080_REG reg)
{
    uint8_t buf[2];
    uint8_t val;
    int ret;

    // Assign the correct register value to val
    switch (reg) {
        case TMP_REG:  val = HDC1080_TMP_REG; break;
        case HMD_REG:  val = HDC1080_HMD_REG; break;
        case CNF_REG:  val = HDC1080_CNF_REG; break;
        case SN1_REG:  val = HDC1080_SN1_REG; break;
        case SN2_REG:  val = HDC1080_SN2_REG; break;
        case SN3_REG:  val = HDC1080_SN3_REG; break;
        case MFID_REG: val = I2C_MFID_REG;    break;
        case DVID_REG: val = I2C_DVID_REG;    break;
    }

    // Perform the read (if we're reading temperature or humidity, delay between the write and read)
    if (!i2c_w(&val, 1)) return -1;
    if (reg == TMP_REG || reg == HMD_REG) vTaskDelay(20 / portTICK_PERIOD_MS);
    if (!i2c_r(buf, 2)) return -1;

    // If we're reading temperature or humidity, return the approriate conversion
    if (reg == TMP_REG) return round(((buf[0]<<8|buf[1]) / 65536.0) * 165.0 - 40.0);
    if (reg == HMD_REG) return round(((buf[0]<<8|buf[1]) / 65536.0) * 100.0);

    // Otherwise return the raw value
    return buf[0]<<8|buf[1];
}

// Shortcut function for writing to the I2C bus
static bool i2c_w(const uint8_t *src, size_t len)
{
    if (DBG) printf("before write of size %i\n", len);
    int ret = i2c_write_timeout_us(I2C_PORT, I2C_ADDRESS, src, len, false, I2C_TIMEOUT);
    if (DBG) printf("after write ret is %i\n", ret);
    if (ret == PICO_ERROR_GENERIC || ret == PICO_ERROR_TIMEOUT) return false;
    return true;
}

// Shortcut function for reading from the I2C bus
static bool i2c_r(uint8_t *dst, size_t len)
{
    if (DBG) printf("before read\n");
    int ret = i2c_read_timeout_us(I2C_PORT, I2C_ADDRESS, dst, len, false, I2C_TIMEOUT);
    if (DBG) {
        printf("after read ret is %i\n", ret);
        printf("buf value: 0x");
        for (int i = 0; i < len; i++) printf("%02x", dst[i]);
        printf("\n");
    }
    if (ret == PICO_ERROR_GENERIC || ret == PICO_ERROR_TIMEOUT) return false;
    return true;
}

// Clears standard output
static void cls()
{
    for (int n = 0; n < 100; n++) printf("\n");
    printf("\e[%d;%df",1,1);
}

//---------------- TASKS ----------------//

// The driver task for the HDC1080, which prints temperature / humidity readings
static void vHDC1080Tsk()
{
    int tmpC, tmpF, hmd;

    while (true) {

        // Delay to slow output
        vTaskDelay(1000 / portTICK_PERIOD_MS);

        // notify the blink task to unblock
        xTaskNotifyGive(xBlinkerTsk);

        // Read the temperature and humidity
        tmpC = read_hdc_reg(TMP_REG);
        tmpF = (tmpC * 1.8) + 32;
        hmd = read_hdc_reg(HMD_REG);

        // Print the information we just read
        // printf("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        // printf("\n┃ Temperature:\t%i°C (%i°F)\t┃", tmpC, tmpF);
        // printf("\n┃ Humidity:\t%i\t\t┃", hmd);
        // printf("\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n");
        printf("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n┃ Temperature:\t%i°C (%i°F)\t┃\n┃ Humidity:\t%i\t\t┃\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n", tmpC, tmpF, hmd);
    }
}

// This task waits for a notification and blinks the LED on for 3 ticks
static void vBlinkerTsk()
{
    while (true) {

        // block until notified to blink (by vCountTsk)
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        // flash the LED on for 3 ticks
        gpio_put(LED_PIN, 1);
        vTaskDelay(3);
        gpio_put(LED_PIN, 0);
    }
}
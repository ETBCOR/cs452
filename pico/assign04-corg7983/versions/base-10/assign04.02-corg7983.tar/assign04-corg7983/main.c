/* * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Class:       CS452 (Real-Time Operating Systems)  *
 * Instructor:  John Shovic                          *
 * Student:     Ethan Corgatelli (corg7983)          *
 * Project:     Assignment 4                         *
 * File:        main.c                               *
 *                                                   *
\* * * * * * * * * * * * * * * * * * * * * * * * * * */

// include this file's header
#include "main.h"


//---------------- DEFINITIONS ----------------//

// define the number of pins in use
#define NUM_PINS 11

// define pin names
#define SevenSegCC1 11
#define SevenSegCC2 10
#define SevenSegA 26
#define SevenSegB 27
#define SevenSegC 29
#define SevenSegD 18
#define SevenSegE 25
#define SevenSegF 7
#define SevenSegG 28
#define SevenSegDP 24
const uint LED_PIN = PICO_DEFAULT_LED_PIN;

// keep an array of the pins for easy initialization
const int PINS[NUM_PINS] = {
    SevenSegCC1, SevenSegCC2,
    SevenSegA, SevenSegB, SevenSegC, SevenSegD, SevenSegE, SevenSegF, SevenSegG,
    SevenSegDP,
    LED_PIN
};


//---------------- PROTOTYPES / HANDLES ----------------//

// utility function prototypes
static void gpio_init_pins();
static void putDigit(int, bool);

// task prototypes
static void vCounterTsk();
static void vBlinkerTsk();
static void vSevSegTsk();

// task/queue handles
static TaskHandle_t xCounterTsk = NULL;
static TaskHandle_t xBlinkerTsk = NULL;
static TaskHandle_t xSevSegTsk  = NULL;
static QueueHandle_t xQueue     = NULL;


//---------------- MAIN ----------------//
int main()
{
    // initialization
    stdio_init_all();
    gpio_init_pins();

    // create a queue of size 1 to communicate the counter value
    xQueue = xQueueCreate(1, sizeof(int));
    if (xQueue == NULL) exit(1); // exit if queue creation fails

    // create the tasks
    xTaskCreate(vCounterTsk, "Counter_Task", 256, NULL, 3, &xCounterTsk);
    xTaskCreate(vBlinkerTsk, "Blinker_Task", 256, NULL, 1, &xBlinkerTsk);
    xTaskCreate(vSevSegTsk,  "Sev_Seg_Task", 256, NULL, 2, &xSevSegTsk );

    // start the task scheduler
    vTaskStartScheduler();

    while(1){};
}


//---------------- UTILITY FUNCTIONS ----------------//

// utility function to init all the pins we need
static void gpio_init_pins()
{
    for (int i = 0; i < NUM_PINS; i++) {
        gpio_init(PINS[i]);
        gpio_set_dir(PINS[i], GPIO_OUT);
    }
}

// put a digit onto one of the two 7-seg displays
static void putDigit(int digit, bool tensPlace)
{
    if (tensPlace) {
        gpio_put(SevenSegCC1, 0);
        gpio_put(SevenSegCC2, 1);
        if (digit == 0) {
            gpio_put(SevenSegA, 0);
            gpio_put(SevenSegB, 0);
            gpio_put(SevenSegC, 0);
            gpio_put(SevenSegD, 0);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 0);
            gpio_put(SevenSegG, 0);
            return;
        }
    } else {
        gpio_put(SevenSegCC1, 1);
        gpio_put(SevenSegCC2, 0);
    }
    switch (digit % 10) {
        case 0:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 1);
            gpio_put(SevenSegF, 1);
            gpio_put(SevenSegG, 0);
            break;
        case 1:
            gpio_put(SevenSegA, 0);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 0);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 0);
            gpio_put(SevenSegG, 0);
            break;
        case 2:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 0);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 1);
            gpio_put(SevenSegF, 0);
            gpio_put(SevenSegG, 1);
            break;
        case 3:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 0);
            gpio_put(SevenSegG, 1);
            break;
        case 4:
            gpio_put(SevenSegA, 0);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 0);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 1);
            gpio_put(SevenSegG, 1);
            break;
        case 5:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 0);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 1);
            gpio_put(SevenSegG, 1);
            break;
        case 6:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 0);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 1);
            gpio_put(SevenSegF, 1);
            gpio_put(SevenSegG, 1);
            break;
        case 7:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 0);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 0);
            gpio_put(SevenSegG, 0);
            break;
        case 8:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 1);
            gpio_put(SevenSegF, 1);
            gpio_put(SevenSegG, 1);
            break;
        case 9:
            gpio_put(SevenSegA, 1);
            gpio_put(SevenSegB, 1);
            gpio_put(SevenSegC, 1);
            gpio_put(SevenSegD, 1);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 1);
            gpio_put(SevenSegG, 1);
            break;
        default:
            gpio_put(SevenSegA, 0);
            gpio_put(SevenSegB, 0);
            gpio_put(SevenSegC, 0);
            gpio_put(SevenSegD, 0);
            gpio_put(SevenSegE, 0);
            gpio_put(SevenSegF, 0);
            gpio_put(SevenSegG, 0);
    }
}


//---------------- TASKS ----------------//

// This task counts (every half second) from 42 to 0 to 42, in a loop,
// updating the queue with the new value, and notifying the blink task
// each time the value changes.
static void vCounterTsk()
{
    int counter = 42;
    int jump = -1;

    while (true) {

        // notify the blink task to unblock
        xTaskNotifyGive(xBlinkerTsk);

        // override the queue's value with the new counter value
        xQueueOverwrite(xQueue, &counter);

        // log the counter value for debugging
        printf(
            "[%s] @ %i: %s %i\n",
            "Counter_Task",
            xTaskGetTickCount(),
            "Counter value is:",
            counter
        );
        
        // Delay the task for 500ms
        vTaskDelay(500 / portTICK_PERIOD_MS);

        // increment the counter
        counter += jump;

        // reverse the jump direction if we're at an extreme
        if (counter == 0 || counter == 42)
            jump *= -1;
    }
}

// This task waits for a notification and blinks the LED on for 3 ticks.
static void vBlinkerTsk()
{
    while (true) {
        // block until notified to blink (by vCountTsk)
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        // flash the LED on for 3 ticks
        gpio_put(LED_PIN, 1);
        vTaskDelay(3);
        gpio_put(LED_PIN, 0);
    }
}

// This task displays the appropriate digits on
// the 7-seg display based on the value in the queue.
static void vSevSegTsk()
{
    int val = 0;

    // delay for a tick so that the queue will
    // have a value when we first peek it.
    vTaskDelay(1);

    while (true) {
        // peek the queue to update val
        xQueuePeek(xQueue, &val, 0);

        // put the 10s digit
        putDigit((val - (val % 10))/10, true);
        // delay this task so that 10s place is visible
        vTaskDelay(1);

        // put the 1s digit
        putDigit(val % 10, false);
        // delay this task so that 1s place is visible
        vTaskDelay(1);
    }
}